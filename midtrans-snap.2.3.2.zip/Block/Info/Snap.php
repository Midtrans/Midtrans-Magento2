<?php
namespace Midtrans\Snap\Block\Info;

use Magento\Payment\Block\Info;

class Snap extends Info
{

}
