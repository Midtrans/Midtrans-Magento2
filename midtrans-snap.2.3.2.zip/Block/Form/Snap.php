<?php

namespace Midtrans\Snap\Block\Form;

class Snap extends \Magento\Payment\Block\Form
{
    /**
     * Instructions text
     *
     * @var string
     */
    protected $_instructions;

    protected $_template = 'form/snap.phtml';
}
